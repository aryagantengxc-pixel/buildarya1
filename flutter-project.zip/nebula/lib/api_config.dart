class ApiConfig {
  static const String baseUrl = 'http://localhost:9239';
  static String get ws => 'wss://ws-localhost:9239';
}