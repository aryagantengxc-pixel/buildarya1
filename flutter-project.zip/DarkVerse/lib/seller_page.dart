import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class SellerPage extends StatefulWidget {
  final String keyToken;
  final String username;

  const SellerPage({
    super.key,
    required this.keyToken,
    required this.username,
  });

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> with TickerProviderStateMixin {
  // ── PALETTE BIRU SOLID ──────────────────────────────────
  static const Color _bgDeep    = Color(0xFFFFFFFF);
  static const Color _bgCard    = Color(0xFFF5F7FA);
  static const Color _bgSurface = Color(0xFFF0F2F5);
  static const Color _border    = Color(0xFFE0E4E8);
  static const Color _textDark  = Color(0xFF1A1A1A);
  static const Color _textSub   = Color(0xFF5F6B7A);
  static const Color _blue      = Color(0xFF1A73E8);
  static const Color _blueLight = Color(0xFFE8F0FE);
  static const Color _red       = Color(0xFFD50000);

  // ── STATE ─────────────────────────────────────────────────
  late final AnimationController _entryCtrl;
  late final Animation<double> _entryAnim;

  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  // SELLER HANYA BISA BUAT MEMBER
  final List<String> roleOptions = ['member'];
  String selectedRole = 'member';
  String newUserRole = 'member';

  int currentPage = 1;
  final int itemsPerPage = 25;

  final createUsernameCtrl = TextEditingController();
  final createPasswordCtrl = TextEditingController();
  final createDayCtrl = TextEditingController();
  final deleteCtrl = TextEditingController();
  final editUsernameCtrl = TextEditingController();
  final editDayCtrl = TextEditingController();

  bool isLoading = false;

  final Map<int, bool> _sectionOpen = {0: true, 1: false, 2: false, 3: false};

  @override
  void initState() {
    super.initState();
    sessionKey = widget.keyToken;

    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _entryAnim = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic);

    _fetchUsers();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    createUsernameCtrl.dispose();
    createPasswordCtrl.dispose();
    createDayCtrl.dispose();
    deleteCtrl.dispose();
    editUsernameCtrl.dispose();
    editDayCtrl.dispose();
    super.dispose();
  }

  // ── API ──────────────────────────────────────────────────
  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://panel.gixsz.my.id:25792/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _showAlert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _showAlert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = start + itemsPerPage;
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final u = deleteCtrl.text.trim();
    if (u.isEmpty) { _showAlert("Peringatan", "Masukkan username yang ingin dihapus."); return; }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://panel.gixsz.my.id:25792/deleteUser?key=$sessionKey&username=$u'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _showAlert("Sukses", "User berhasil dihapus.");
        deleteCtrl.clear();
        _fetchUsers();
      } else {
        _showAlert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) { _showAlert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameCtrl.text.trim();
    final p = createPasswordCtrl.text.trim();
    final d = createDayCtrl.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _showAlert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
        'http://panel.gixsz.my.id:25792/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=member', // ← HARUS MEMBER
      ));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _showAlert("Sukses", "Akun member berhasil dibuat.");
        createUsernameCtrl.clear();
        createPasswordCtrl.clear();
        createDayCtrl.clear();
        _fetchUsers();
      } else {
        _showAlert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) { _showAlert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameCtrl.text.trim();
    final d = editDayCtrl.text.trim();
    if (u.isEmpty || d.isEmpty) { _showAlert("Peringatan", "Semua field wajib diisi."); return; }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
        'http://panel.gixsz.my.id:25792/editUser?key=$sessionKey&username=$u&addDays=$d',
      ));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _showAlert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameCtrl.clear();
        editDayCtrl.clear();
        _fetchUsers();
      } else {
        _showAlert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) { _showAlert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  // ── DIALOG ─────────────────────────────────────────────────
  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _bgCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _blue.withOpacity(0.2)),
            boxShadow: [BoxShadow(color: _blue.withOpacity(0.08), blurRadius: 40)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: _blue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _blue.withOpacity(0.2)),
                  ),
                  child: Icon(Icons.info_outline_rounded, color: _blue, size: 18),
                ),
                const SizedBox(width: 12),
                Text(title.toUpperCase(), style: TextStyle(
                  color: _blue, fontSize: 13,
                  fontWeight: FontWeight.w800, letterSpacing: 1.5,
                )),
              ]),
              const SizedBox(height: 14),
              Container(height: 1, color: _border),
              const SizedBox(height: 14),
              Text(msg, style: TextStyle(
                color: _textSub, fontSize: 13, height: 1.6,
              )),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: _blue.withOpacity(0.1),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(color: _blue.withOpacity(0.2)),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 13),
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: Text("OK", style: TextStyle(
                    color: _blue,
                    fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1,
                  )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _confirmDelete(String username) async {
    return await showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _bgCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _blue.withOpacity(0.25)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: _blue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(Icons.warning_amber_rounded, color: _blue, size: 18),
                ),
                const SizedBox(width: 12),
                Text("KONFIRMASI", style: TextStyle(
                  color: _blue, fontSize: 13,
                  fontWeight: FontWeight.w800, letterSpacing: 1.5,
                )),
              ]),
              const SizedBox(height: 14),
              Container(height: 1, color: _border),
              const SizedBox(height: 14),
              Text("Hapus user \"$username\"?\nTindakan ini tidak bisa dibatalkan.", style: TextStyle(
                color: _textSub, fontSize: 13, height: 1.6,
              )),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(
                  child: TextButton(
                    style: TextButton.styleFrom(
                      backgroundColor: _bgSurface,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    onPressed: () => Navigator.pop(context, false),
                    child: Text("BATAL", style: TextStyle(
                      color: _textSub, fontSize: 11, fontWeight: FontWeight.w700,
                    )),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextButton(
                    style: TextButton.styleFrom(
                      backgroundColor: _red.withOpacity(0.12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(color: _red.withOpacity(0.3)),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    onPressed: () => Navigator.pop(context, true),
                    child: Text("HAPUS", style: TextStyle(
                      color: _red, fontSize: 11, fontWeight: FontWeight.w700,
                    )),
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
    ) ?? false;
  }

  // ── BUILD ──────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Scaffold(
        backgroundColor: _bgDeep,
        body: SafeArea(
          child: FadeTransition(
            opacity: _entryAnim,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 0.03), end: Offset.zero,
              ).animate(_entryAnim),
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  const SliverToBoxAdapter(child: SizedBox(height: 16)),
                  SliverToBoxAdapter(child: _buildHeader()),
                  const SliverToBoxAdapter(child: SizedBox(height: 16)),
                  SliverToBoxAdapter(child: _buildStatsRow()),
                  const SliverToBoxAdapter(child: SizedBox(height: 20)),
                  SliverToBoxAdapter(child: _buildSectionDivider("MANAGE MEMBERS")),
                  const SliverToBoxAdapter(child: SizedBox(height: 12)),

                  SliverToBoxAdapter(child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildSection(
                      id: 0,
                      icon: FontAwesomeIcons.userSlash,
                      title: "DELETE MEMBER",
                      child: _buildDeleteSection(),
                    ),
                  )),
                  const SliverToBoxAdapter(child: SizedBox(height: 8)),

                  SliverToBoxAdapter(child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildSection(
                      id: 1,
                      icon: FontAwesomeIcons.userPlus,
                      title: "CREATE MEMBER",
                      child: _buildCreateSection(),
                    ),
                  )),
                  const SliverToBoxAdapter(child: SizedBox(height: 8)),

                  SliverToBoxAdapter(child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildSection(
                      id: 2,
                      icon: FontAwesomeIcons.clock,
                      title: "EXTEND DURATION",
                      child: _buildExtendSection(),
                    ),
                  )),
                  const SliverToBoxAdapter(child: SizedBox(height: 8)),

                  SliverToBoxAdapter(child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildSection(
                      id: 3,
                      icon: FontAwesomeIcons.users,
                      title: "MEMBER LIST",
                      child: _buildUserListSection(),
                    ),
                  )),

                  SliverToBoxAdapter(child: _buildFooter()),
                  const SliverToBoxAdapter(child: SizedBox(height: 32)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── HEADER ─────────────────────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _border),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(children: [
          Container(
            width: 52, height: 52,
            decoration: BoxDecoration(
              color: _blue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _blue.withOpacity(0.2)),
            ),
            child: Icon(Icons.storefront_rounded, color: _blue, size: 26),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text("SELLER", style: TextStyle(
                color: _textDark, fontSize: 22,
                fontWeight: FontWeight.w900, letterSpacing: 2, height: 1,
              )),
              const SizedBox(height: 5),
              Text("Member Management · ${widget.username}", style: TextStyle(
                color: _textSub, fontSize: 11, letterSpacing: 1,
              )),
            ]),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: _blue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: _blue.withOpacity(0.25)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.verified_user_rounded, color: _blue, size: 12),
              const SizedBox(width: 5),
              Text("SELLER", style: TextStyle(
                color: _blue, fontSize: 10,
                fontWeight: FontWeight.w700, letterSpacing: 1,
              )),
            ]),
          ),
        ]),
      ),
    );
  }

  // ── STATS ROW ────────────────────────────────────────────
  Widget _buildStatsRow() {
    final stats = [
      {'val': '${fullUserList.length}', 'lbl': 'TOTAL', 'icon': Icons.people_rounded},
      {'val': '${filteredList.length}', 'lbl': 'MEMBER', 'icon': Icons.filter_list_rounded},
      {'val': '${roleOptions.length}', 'lbl': 'ROLES', 'icon': Icons.verified_user_rounded},
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: List.generate(stats.length, (i) => Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: i < stats.length - 1 ? 8 : 0),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
              decoration: BoxDecoration(
                color: _bgCard,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _border),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(children: [
                Icon(stats[i]['icon'] as IconData, color: _blue.withOpacity(0.6), size: 16),
                const SizedBox(height: 6),
                Text(stats[i]['val'] as String, style: TextStyle(
                  color: _textDark, fontSize: 14, fontWeight: FontWeight.w700,
                )),
                const SizedBox(height: 2),
                Text(stats[i]['lbl'] as String, style: TextStyle(
                  color: _textSub, fontSize: 8, letterSpacing: 1,
                )),
              ]),
            ),
          ),
        )),
      ),
    );
  }

  // ── SECTION DIVIDER ──────────────────────────────────────
  Widget _buildSectionDivider(String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(children: [
        Container(width: 3, height: 14, decoration: BoxDecoration(
          color: _blue, borderRadius: BorderRadius.circular(2),
        )),
        const SizedBox(width: 10),
        Text(label, style: TextStyle(
          color: _textSub, fontSize: 10, letterSpacing: 2,
        )),
        const SizedBox(width: 10),
        Expanded(child: Container(height: 1, decoration: BoxDecoration(
          gradient: LinearGradient(colors: [_border, Colors.transparent]),
        ))),
      ]),
    );
  }

  // ── ACCORDION SECTION ──────────────────────────────────
  Widget _buildSection({
    required int id,
    required IconData icon,
    required String title,
    required Widget child,
  }) {
    final isOpen = _sectionOpen[id] ?? false;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      margin: const EdgeInsets.only(bottom: 0),
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isOpen ? _blue.withOpacity(0.3) : _border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Column(children: [
          InkWell(
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() => _sectionOpen[id] = !isOpen);
            },
            borderRadius: BorderRadius.circular(16),
            splashColor: _blue.withOpacity(0.05),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: isOpen ? _blue.withOpacity(0.12) : _bgSurface,
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(color: isOpen ? _blue.withOpacity(0.25) : _border),
                  ),
                  child: Center(child: FaIcon(icon, color: isOpen ? _blue : _textSub, size: 16)),
                ),
                const SizedBox(width: 14),
                Expanded(child: Text(title, style: TextStyle(
                  color: isOpen ? _blue : _textDark,
                  fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 1.5,
                ))),
                AnimatedRotation(
                  turns: isOpen ? 0.5 : 0,
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOutCubic,
                  child: Icon(Icons.keyboard_arrow_down_rounded,
                    color: isOpen ? _blue : _textSub, size: 20),
                ),
              ]),
            ),
          ),
          AnimatedSize(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOutCubic,
            child: isOpen
                ? Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    child: Column(children: [
                      Container(height: 1, color: _border),
                      const SizedBox(height: 16),
                      child,
                    ]),
                  )
                : const SizedBox.shrink(),
          ),
        ]),
      ),
    );
  }

  // ── SECTION CONTENTS ────────────────────────────────────

  Widget _buildDeleteSection() {
    return Column(children: [
      _buildInput(label: "Username Target", ctrl: deleteCtrl, icon: FontAwesomeIcons.user),
      const SizedBox(height: 4),
      _buildActionButton(
        label: "DELETE MEMBER",
        icon: Icons.delete_rounded,
        onTap: isLoading ? null : _deleteUser,
        color: _red,
      ),
    ]);
  }

  Widget _buildCreateSection() {
    return Column(children: [
      _buildInput(label: "Username", ctrl: createUsernameCtrl, icon: FontAwesomeIcons.user),
      _buildInput(label: "Password", ctrl: createPasswordCtrl, icon: FontAwesomeIcons.lock, obscure: true),
      _buildInput(label: "Durasi (Hari)", ctrl: createDayCtrl, icon: FontAwesomeIcons.calendarDay, num: true),
      const SizedBox(height: 8),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: _blueLight,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _blue.withOpacity(0.2)),
        ),
        child: Row(children: [
          Icon(Icons.info_outline, color: _blue, size: 16),
          const SizedBox(width: 10),
          Text("Role: MEMBER (fixed)", style: TextStyle(
            color: _blue, fontSize: 12, fontWeight: FontWeight.w600,
          )),
        ]),
      ),
      const SizedBox(height: 12),
      _buildActionButton(
        label: "CREATE MEMBER",
        icon: Icons.add_circle_rounded,
        onTap: isLoading ? null : _createAccount,
        color: _blue,
      ),
    ]);
  }

  Widget _buildExtendSection() {
    return Column(children: [
      _buildInput(label: "Username Target", ctrl: editUsernameCtrl, icon: FontAwesomeIcons.userPen),
      _buildInput(label: "Tambah Hari", ctrl: editDayCtrl, icon: FontAwesomeIcons.calendarPlus, num: true),
      const SizedBox(height: 4),
      _buildActionButton(
        label: "ADD DAYS",
        icon: Icons.calendar_month_rounded,
        onTap: isLoading ? null : _editUser,
        color: _blue,
      ),
    ]);
  }

  Widget _buildUserListSection() {
    return Column(children: [
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: _blueLight,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _blue.withOpacity(0.2)),
        ),
        child: Row(children: [
          Icon(Icons.filter_list, color: _blue, size: 16),
          const SizedBox(width: 10),
          Text("Filter: MEMBER", style: TextStyle(
            color: _blue, fontSize: 12, fontWeight: FontWeight.w600,
          )),
        ]),
      ),
      const SizedBox(height: 16),

      if (isLoading)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 24),
          child: Column(children: [
            SizedBox(
              width: 28, height: 28,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: _blue.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 12),
            Text("Memuat data...", style: TextStyle(
              color: _textSub, fontSize: 11,
            )),
          ]),
        )
      else if (filteredList.isEmpty)
        Container(
          padding: const EdgeInsets.symmetric(vertical: 28),
          child: Column(children: [
            Icon(Icons.people_outline_rounded, color: _textSub.withOpacity(0.3), size: 36),
            const SizedBox(height: 10),
            Text("Tidak ada member", style: TextStyle(
              color: _textSub, fontSize: 12,
            )),
          ]),
        )
      else
        Column(children: [
          ..._getCurrentPageData().map((u) => _buildUserItem(u as Map)).toList(),
          if (totalPages > 1) ...[
            const SizedBox(height: 16),
            _buildPagination(),
          ],
        ]),
    ]);
  }

  // ── SHARED WIDGETS ─────────────────────────────────────

  Widget _buildInput({
    required String label,
    required TextEditingController ctrl,
    required IconData icon,
    bool obscure = false,
    bool num = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: ctrl,
        obscureText: obscure,
        keyboardType: num ? TextInputType.number : TextInputType.text,
        style: TextStyle(color: _textDark, fontSize: 13),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: _textSub, fontSize: 12),
          prefixIcon: Padding(
            padding: const EdgeInsets.all(14),
            child: FaIcon(icon, color: _blue.withOpacity(0.7), size: 15),
          ),
          filled: true,
          fillColor: _bgSurface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _blue.withOpacity(0.5), width: 1.5),
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required VoidCallback? onTap,
    required Color color,
  }) {
    return SizedBox(
      width: double.infinity,
      child: TextButton(
        onPressed: onTap == null ? null : () {
          HapticFeedback.lightImpact();
          onTap();
        },
        style: TextButton.styleFrom(
          backgroundColor: color.withOpacity(0.1),
          disabledBackgroundColor: _bgSurface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: color.withOpacity(0.25)),
          ),
          padding: const EdgeInsets.symmetric(vertical: 14),
        ),
        child: isLoading
            ? SizedBox(
                width: 18, height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: color),
              )
            : Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(icon, color: color, size: 16),
                const SizedBox(width: 10),
                Text(label, style: TextStyle(
                  color: color,
                  fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.5,
                )),
              ]),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _bgSurface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _border),
      ),
      child: Row(children: [
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            color: _blue.withOpacity(0.08),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _blue.withOpacity(0.15)),
          ),
          child: Icon(Icons.person_rounded, color: _blue, size: 18),
        ),
        const SizedBox(width: 12),

        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(user['username'] ?? '-', style: TextStyle(
            color: _textDark, fontSize: 13, fontWeight: FontWeight.w600,
          )),
          const SizedBox(height: 3),
          Row(children: [
            _buildMiniChip('MEMBER', _blue),
            const SizedBox(width: 6),
            Text(user['expiredDate'] ?? '-', style: TextStyle(
              color: _textSub, fontSize: 10,
            )),
          ]),
        ])),

        InkWell(
          onTap: () async {
            HapticFeedback.mediumImpact();
            final ok = await _confirmDelete(user['username'] ?? '');
            if (ok) {
              deleteCtrl.text = user['username'];
              _deleteUser();
            }
          },
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _red.withOpacity(0.06),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _red.withOpacity(0.12)),
            ),
            child: Icon(Icons.delete_outline_rounded, color: _red, size: 16),
          ),
        ),
      ]),
    );
  }

  Widget _buildMiniChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Text(text, style: TextStyle(
        color: color, fontSize: 8,
        fontWeight: FontWeight.w800, letterSpacing: 0.5,
      )),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: List.generate(totalPages, (i) {
        final page = i + 1;
        final active = page == currentPage;
        return GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            setState(() => currentPage = page);
          },
          child: Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: active ? _blue.withOpacity(0.12) : _bgSurface,
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: active ? _blue.withOpacity(0.35) : _border),
            ),
            child: Center(
              child: Text("$page", style: TextStyle(
                color: active ? _blue : _textSub,
                fontSize: 11, fontWeight: FontWeight.w700,
              )),
            ),
          ),
        );
      }),
    );
  }

  // ── FOOTER ──────────────────────────────────────────────
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: Column(children: [
        Container(height: 1, color: _border),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.info_outline_rounded, color: _textSub.withOpacity(0.4), size: 12),
          const SizedBox(width: 6),
          Text("v7.0 · SELLER ACCESS", style: TextStyle(
            color: _textSub.withOpacity(0.4), fontSize: 9,
            letterSpacing: 1.5,
          )),
        ]),
      ]),
    );
  }
}