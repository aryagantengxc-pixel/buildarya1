import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ─────────────────────────────────────────────
//  AdminPage  —  Light UI  v7.0
// ─────────────────────────────────────────────
class AdminPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const AdminPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> with TickerProviderStateMixin {
  // ── Palette (Putih polos kayak dashboard) ──
  static const Color _bgDeep    = Color(0xFFFFFFFF);
  static const Color _bgCard    = Color(0xFFF5F5F5);
  static const Color _bgSurface = Color(0xFFFAFAFA);
  static const Color _border    = Color(0xFFE0E0E0);
  static const Color _textDark  = Color(0xFF1A1A1A);
  static const Color _textSub   = Color(0xFF666666);
  static const Color _green     = Color(0xFF00C853);
  static const Color _red       = Color(0xFFFF0040);
  static const Color _blueAccent= Color(0xFF1A73E8);

  // ── State ────────────────────────────────────
  late final AnimationController _entryCtrl;
  late final Animation<double> _entryAnim;

  late String sessionKey;
  List<dynamic> fullUserList  = [];
  List<dynamic> filteredList  = [];

  // ADMIN TIDAK BISA BIKIN ADMIN!
  final roleOptions = ['reseller', 'member'];
  String selectedRole = 'member';
  String newUserRole  = 'member';

  int currentPage  = 1;
  final int itemsPerPage = 25;

  final createUsernameCtrl = TextEditingController();
  final createPasswordCtrl = TextEditingController();
  final createDayCtrl      = TextEditingController();
  final deleteCtrl         = TextEditingController();
  final editUsernameCtrl   = TextEditingController();
  final editDayCtrl        = TextEditingController();

  bool isLoading = false;

  final Map<int, bool> _sectionOpen = {0: true, 1: false, 2: false, 3: false};

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;

    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _entryAnim = CurvedAnimation(parent: _entryCtrl, curve: Curves.easeOutCubic);

    _fetchUsers();
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    createUsernameCtrl.dispose();
    createPasswordCtrl.dispose();
    createDayCtrl.dispose();
    deleteCtrl.dispose();
    editUsernameCtrl.dispose();
    editDayCtrl.dispose();
    super.dispose();
  }

  // ── API ──────────────────────────────────────
  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://panel.gixsz.my.id:25792/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _showAlert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _showAlert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage  = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end   = start + itemsPerPage;
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final u = deleteCtrl.text.trim();
    if (u.isEmpty) { _showAlert("Peringatan", "Masukkan username yang ingin dihapus."); return; }
    setState(() => isLoading = true);
    try {
      final res  = await http.get(Uri.parse('http://panel.gixsz.my.id:25792/deleteUser?key=$sessionKey&username=$u'));
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _showAlert("Sukses", "User berhasil dihapus.");
        deleteCtrl.clear();
        _fetchUsers();
      } else {
        _showAlert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) { _showAlert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameCtrl.text.trim();
    final p = createPasswordCtrl.text.trim();
    final d = createDayCtrl.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) { _showAlert("Peringatan", "Semua field wajib diisi."); return; }
    setState(() => isLoading = true);
    try {
      final res  = await http.get(Uri.parse(
        'http://panel.gixsz.my.id:25792/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      ));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _showAlert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameCtrl.clear(); createPasswordCtrl.clear(); createDayCtrl.clear();
        setState(() => newUserRole = 'member');
        _fetchUsers();
      } else {
        _showAlert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) { _showAlert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameCtrl.text.trim();
    final d = editDayCtrl.text.trim();
    if (u.isEmpty || d.isEmpty) { _showAlert("Peringatan", "Semua field wajib diisi."); return; }
    setState(() => isLoading = true);
    try {
      final res  = await http.get(Uri.parse(
        'http://panel.gixsz.my.id:25792/editUser?key=$sessionKey&username=$u&addDays=$d',
      ));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _showAlert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameCtrl.clear(); editDayCtrl.clear();
        _fetchUsers();
      } else {
        _showAlert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) { _showAlert("Error", "Gagal menghubungi server."); }
    setState(() => isLoading = false);
  }

  // ── Dialogs ───────────────────────────────────
  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _bgCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _green.withOpacity(0.2)),
            boxShadow: [BoxShadow(color: _green.withOpacity(0.08), blurRadius: 40)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: _green.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _green.withOpacity(0.2)),
                  ),
                  child: const Icon(Icons.info_outline_rounded, color: _green, size: 18),
                ),
                const SizedBox(width: 12),
                Text(title.toUpperCase(), style: const TextStyle(
                  color: _green, fontSize: 13,
                  fontWeight: FontWeight.w800, letterSpacing: 1.5,
                )),
              ]),
              const SizedBox(height: 14),
              Container(height: 1, color: _border),
              const SizedBox(height: 14),
              Text(msg, style: const TextStyle(
                color: _textSub, fontSize: 13, height: 1.6,
              )),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  style: TextButton.styleFrom(
                    backgroundColor: _green.withOpacity(0.1),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(color: _green.withOpacity(0.2)),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 13),
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: const Text("OK", style: TextStyle(
                    color: _green,
                    fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1,
                  )),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _confirmDelete(String username) async {
    return await showDialog<bool>(
      context: context,
      barrierColor: Colors.black.withOpacity(0.75),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _bgCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _green.withOpacity(0.25)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: _green.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.warning_amber_rounded, color: _green, size: 18),
                ),
                const SizedBox(width: 12),
                const Text("KONFIRMASI", style: TextStyle(
                  color: _green, fontSize: 13,
                  fontWeight: FontWeight.w800, letterSpacing: 1.5,
                )),
              ]),
              const SizedBox(height: 14),
              Container(height: 1, color: _border),
              const SizedBox(height: 14),
              Text("Hapus user \"$username\"?\nTindakan ini tidak bisa dibatalkan.", style: const TextStyle(
                color: _textSub, fontSize: 13, height: 1.6,
              )),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(
                  child: TextButton(
                    style: TextButton.styleFrom(
                      backgroundColor: _bgSurface,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text("BATAL", style: TextStyle(
                      color: _textSub, fontSize: 11, fontWeight: FontWeight.w700,
                    )),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextButton(
                    style: TextButton.styleFrom(
                      backgroundColor: _red.withOpacity(0.12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: BorderSide(color: _red.withOpacity(0.3)),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 13),
                    ),
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text("HAPUS", style: TextStyle(
                      color: _red, fontSize: 11, fontWeight: FontWeight.w700,
                    )),
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
    ) ?? false;
  }

  // ── Build ─────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.dark,
      child: Scaffold(
        backgroundColor: _bgDeep,
        body: SafeArea(
          child: FadeTransition(
            opacity: _entryAnim,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(0, 0.03), end: Offset.zero,
              ).animate(_entryAnim),
              child: CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  const SliverToBoxAdapter(child: SizedBox(height: 16)),
                  SliverToBoxAdapter(child: _buildHeader()),
                  const SliverToBoxAdapter(child: SizedBox(height: 16)),
                  SliverToBoxAdapter(child: _buildStatsRow()),
                  const SliverToBoxAdapter(child: SizedBox(height: 20)),
                  SliverToBoxAdapter(child: _buildSectionDivider("PANEL CONTROLS")),
                  const SliverToBoxAdapter(child: SizedBox(height: 12)),

                  SliverToBoxAdapter(child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildSection(
                      id: 0,
                      icon: FontAwesomeIcons.userSlash,
                      title: "DELETE USER",
                      child: _buildDeleteSection(),
                    ),
                  )),
                  const SliverToBoxAdapter(child: SizedBox(height: 8)),

                  SliverToBoxAdapter(child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildSection(
                      id: 1,
                      icon: FontAwesomeIcons.userPlus,
                      title: "CREATE ACCOUNT",
                      child: _buildCreateSection(),
                    ),
                  )),
                  const SliverToBoxAdapter(child: SizedBox(height: 8)),

                  SliverToBoxAdapter(child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildSection(
                      id: 2,
                      icon: FontAwesomeIcons.clock,
                      title: "EXTEND DURATION",
                      child: _buildExtendSection(),
                    ),
                  )),
                  const SliverToBoxAdapter(child: SizedBox(height: 8)),

                  SliverToBoxAdapter(child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: _buildSection(
                      id: 3,
                      icon: FontAwesomeIcons.users,
                      title: "USER LIST",
                      child: _buildUserListSection(),
                    ),
                  )),

                  SliverToBoxAdapter(child: _buildFooter()),
                  const SliverToBoxAdapter(child: SizedBox(height: 32)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── Header ───────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _bgCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _border),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(children: [
          Container(
            width: 52, height: 52,
            decoration: BoxDecoration(
              color: _green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _green.withOpacity(0.2)),
            ),
            child: const Icon(Icons.admin_panel_settings_rounded, color: _green, size: 26),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text("ADMIN", style: TextStyle(
                color: _textDark, fontSize: 22,
                fontWeight: FontWeight.w900, letterSpacing: 2, height: 1,
              )),
              const SizedBox(height: 5),
              Text("Control Panel · ${widget.username}", style: const TextStyle(
                color: _textSub, fontSize: 11, letterSpacing: 1,
              )),
            ]),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: _green.withOpacity(0.1),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: _green.withOpacity(0.25)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.military_tech_rounded, color: _green, size: 12),
              const SizedBox(width: 5),
              const Text("ADMIN", style: TextStyle(
                color: _green, fontSize: 10,
                fontWeight: FontWeight.w700, letterSpacing: 1,
              )),
            ]),
          ),
        ]),
      ),
    );
  }

  // ── Stats Row ────────────────────────────────
  Widget _buildStatsRow() {
    final stats = [
      {'val': '${fullUserList.length}', 'lbl': 'TOTAL', 'icon': Icons.people_rounded},
      {'val': '${filteredList.length}', 'lbl': selectedRole.toUpperCase(), 'icon': Icons.filter_list_rounded},
      {'val': '${roleOptions.length}', 'lbl': 'ROLES', 'icon': Icons.verified_user_rounded},
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: List.generate(stats.length, (i) => Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: i < stats.length - 1 ? 8 : 0),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
              decoration: BoxDecoration(
                color: _bgCard,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _border),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.03),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(children: [
                Icon(stats[i]['icon'] as IconData, color: _green.withOpacity(0.6), size: 16),
                const SizedBox(height: 6),
                Text(stats[i]['val'] as String, style: const TextStyle(
                  color: _textDark, fontSize: 14, fontWeight: FontWeight.w700,
                )),
                const SizedBox(height: 2),
                Text(stats[i]['lbl'] as String, style: const TextStyle(
                  color: _textSub, fontSize: 8, letterSpacing: 1,
                )),
              ]),
            ),
          ),
        )),
      ),
    );
  }

  // ── Section Divider ──────────────────────────
  Widget _buildSectionDivider(String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(children: [
        Container(width: 3, height: 14, decoration: BoxDecoration(
          color: _green, borderRadius: BorderRadius.circular(2),
        )),
        const SizedBox(width: 10),
        Text(label, style: const TextStyle(
          color: _textSub, fontSize: 10, letterSpacing: 2,
        )),
        const SizedBox(width: 10),
        Expanded(child: Container(height: 1, decoration: BoxDecoration(
          gradient: LinearGradient(colors: [_border, Colors.transparent]),
        ))),
      ]),
    );
  }

  // ── Accordion Section ────────────────────────
  Widget _buildSection({
    required int id,
    required IconData icon,
    required String title,
    required Widget child,
  }) {
    final isOpen = _sectionOpen[id] ?? false;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      margin: const EdgeInsets.only(bottom: 0),
      decoration: BoxDecoration(
        color: _bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isOpen ? _green.withOpacity(0.3) : _border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Column(children: [
          InkWell(
            onTap: () {
              HapticFeedback.selectionClick();
              setState(() => _sectionOpen[id] = !isOpen);
            },
            borderRadius: BorderRadius.circular(16),
            splashColor: _green.withOpacity(0.05),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(children: [
                Container(
                  width: 40, height: 40,
                  decoration: BoxDecoration(
                    color: isOpen ? _green.withOpacity(0.12) : _bgSurface,
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(color: isOpen ? _green.withOpacity(0.25) : _border),
                  ),
                  child: Center(child: FaIcon(icon, color: isOpen ? _green : _textSub, size: 16)),
                ),
                const SizedBox(width: 14),
                Expanded(child: Text(title, style: TextStyle(
                  color: isOpen ? _green : _textDark,
                  fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 1.5,
                ))),
                AnimatedRotation(
                  turns: isOpen ? 0.5 : 0,
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOutCubic,
                  child: Icon(Icons.keyboard_arrow_down_rounded,
                    color: isOpen ? _green : _textSub, size: 20),
                ),
              ]),
            ),
          ),
          AnimatedSize(
            duration: const Duration(milliseconds: 280),
            curve: Curves.easeOutCubic,
            child: isOpen
                ? Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    child: Column(children: [
                      Container(height: 1, color: _border),
                      const SizedBox(height: 16),
                      child,
                    ]),
                  )
                : const SizedBox.shrink(),
          ),
        ]),
      ),
    );
  }

  // ── Section Contents ─────────────────────────

  Widget _buildDeleteSection() {
    return Column(children: [
      _buildInput(label: "Username Target", ctrl: deleteCtrl, icon: FontAwesomeIcons.user),
      const SizedBox(height: 4),
      _buildActionButton(
        label: "DELETE ACCOUNT",
        icon: Icons.delete_rounded,
        onTap: isLoading ? null : _deleteUser,
        color: _red,
      ),
    ]);
  }

  Widget _buildCreateSection() {
    return Column(children: [
      _buildInput(label: "Username", ctrl: createUsernameCtrl, icon: FontAwesomeIcons.user),
      _buildInput(label: "Password", ctrl: createPasswordCtrl, icon: FontAwesomeIcons.lock, obscure: true),
      _buildInput(label: "Durasi (Hari)", ctrl: createDayCtrl, icon: FontAwesomeIcons.calendarDay, num: true),
      _buildDropdown(
        value: newUserRole,
        onChanged: (v) => setState(() => newUserRole = v ?? 'member'),
        label: "Role",
      ),
      const SizedBox(height: 12),
      _buildActionButton(
        label: "CREATE ACCOUNT",
        icon: Icons.add_circle_rounded,
        onTap: isLoading ? null : _createAccount,
        color: _green,
      ),
    ]);
  }

  Widget _buildExtendSection() {
    return Column(children: [
      _buildInput(label: "Username Target", ctrl: editUsernameCtrl, icon: FontAwesomeIcons.userPen),
      _buildInput(label: "Tambah Hari", ctrl: editDayCtrl, icon: FontAwesomeIcons.calendarPlus, num: true),
      const SizedBox(height: 4),
      _buildActionButton(
        label: "ADD DAYS",
        icon: Icons.calendar_month_rounded,
        onTap: isLoading ? null : _editUser,
        color: _blueAccent,
      ),
    ]);
  }

  Widget _buildUserListSection() {
    return Column(children: [
      _buildDropdown(
        value: selectedRole,
        onChanged: (v) {
          if (v != null) { selectedRole = v; _filterAndPaginate(); }
        },
        label: "Filter Role",
      ),
      const SizedBox(height: 16),

      if (isLoading)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 24),
          child: Column(children: [
            SizedBox(
              width: 28, height: 28,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                color: _green.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 12),
            const Text("Memuat data...", style: TextStyle(
              color: _textSub, fontSize: 11,
            )),
          ]),
        )
      else if (filteredList.isEmpty)
        Container(
          padding: const EdgeInsets.symmetric(vertical: 28),
          child: Column(children: [
            Icon(Icons.people_outline_rounded, color: _textSub.withOpacity(0.3), size: 36),
            const SizedBox(height: 10),
            const Text("Tidak ada user", style: TextStyle(
              color: _textSub, fontSize: 12,
            )),
          ]),
        )
      else
        Column(children: [
          ..._getCurrentPageData().map((u) => _buildUserItem(u as Map)).toList(),
          if (totalPages > 1) ...[
            const SizedBox(height: 16),
            _buildPagination(),
          ],
        ]),
    ]);
  }

  // ── Shared Widgets ───────────────────────────

  Widget _buildInput({
    required String label,
    required TextEditingController ctrl,
    required IconData icon,
    bool obscure = false,
    bool num = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: ctrl,
        obscureText: obscure,
        keyboardType: num ? TextInputType.number : TextInputType.text,
        style: const TextStyle(color: _textDark, fontSize: 13),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: _textSub, fontSize: 12),
          prefixIcon: Padding(
            padding: const EdgeInsets.all(14),
            child: FaIcon(icon, color: _green.withOpacity(0.7), size: 15),
          ),
          filled: true,
          fillColor: _bgSurface,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _border),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: _border),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: _green.withOpacity(0.5), width: 1.5),
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String value,
    required ValueChanged<String?> onChanged,
    required String label,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      decoration: BoxDecoration(
        color: _bgSurface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _border),
      ),
      child: Row(children: [
        Icon(Icons.shield_rounded, color: _green.withOpacity(0.7), size: 16),
        const SizedBox(width: 12),
        Expanded(
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              dropdownColor: _bgCard,
              style: const TextStyle(color: _textDark, fontSize: 13),
              icon: const Icon(Icons.keyboard_arrow_down_rounded, color: _textSub, size: 18),
              items: roleOptions.map((r) => DropdownMenuItem(
                value: r,
                child: Text(r.toUpperCase()),
              )).toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildActionButton({
    required String label,
    required IconData icon,
    required VoidCallback? onTap,
    required Color color,
  }) {
    return SizedBox(
      width: double.infinity,
      child: TextButton(
        onPressed: onTap == null ? null : () {
          HapticFeedback.lightImpact();
          onTap();
        },
        style: TextButton.styleFrom(
          backgroundColor: color.withOpacity(0.1),
          disabledBackgroundColor: _bgSurface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: color.withOpacity(0.25)),
          ),
          padding: const EdgeInsets.symmetric(vertical: 14),
        ),
        child: isLoading
            ? SizedBox(
                width: 18, height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: color),
              )
            : Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(icon, color: color, size: 16),
                const SizedBox(width: 10),
                Text(label, style: TextStyle(
                  color: color,
                  fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.5,
                )),
              ]),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _bgSurface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _border),
      ),
      child: Row(children: [
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
            color: _green.withOpacity(0.08),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _green.withOpacity(0.15)),
          ),
          child: const Icon(Icons.person_rounded, color: _green, size: 18),
        ),
        const SizedBox(width: 12),

        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(user['username'] ?? '-', style: const TextStyle(
            color: _textDark, fontSize: 13, fontWeight: FontWeight.w600,
          )),
          const SizedBox(height: 3),
          Row(children: [
            _buildMiniChip(user['role']?.toString().toUpperCase() ?? '-', _green),
            const SizedBox(width: 6),
            Text(user['expiredDate'] ?? '-', style: const TextStyle(
              color: _textSub, fontSize: 10,
            )),
          ]),
        ])),

        InkWell(
          onTap: () async {
            HapticFeedback.mediumImpact();
            final ok = await _confirmDelete(user['username'] ?? '');
            if (ok) {
              deleteCtrl.text = user['username'];
              _deleteUser();
            }
          },
          borderRadius: BorderRadius.circular(8),
          child: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _red.withOpacity(0.06),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _red.withOpacity(0.12)),
            ),
            child: const Icon(Icons.delete_outline_rounded, color: _red, size: 16),
          ),
        ),
      ]),
    );
  }

  Widget _buildMiniChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Text(text, style: TextStyle(
        color: color, fontSize: 8,
        fontWeight: FontWeight.w800, letterSpacing: 0.5,
      )),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: List.generate(totalPages, (i) {
        final page = i + 1;
        final active = page == currentPage;
        return GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            setState(() => currentPage = page);
          },
          child: Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: active ? _green.withOpacity(0.12) : _bgSurface,
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: active ? _green.withOpacity(0.35) : _border),
            ),
            child: Center(
              child: Text("$page", style: TextStyle(
                color: active ? _green : _textSub,
                fontSize: 11, fontWeight: FontWeight.w700,
              )),
            ),
          ),
        );
      }),
    );
  }

  // ── Footer ───────────────────────────────────
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: Column(children: [
        Container(height: 1, color: _border),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.info_outline_rounded, color: _textSub.withOpacity(0.4), size: 12),
          const SizedBox(width: 6),
          Text("v7.0 · ADMIN ACCESS", style: TextStyle(
            color: _textSub.withOpacity(0.4), fontSize: 9,
            letterSpacing: 1.5,
          )),
        ]),
      ]),
    );
  }
}